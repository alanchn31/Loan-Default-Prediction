import json
import pyspark.sql.functions as fn
import pyspark.sql.types as typ
import pyspark.ml.feature as sf
from pipe.pipe import Pipe
from pip.IF import IF
from transformers import *
from pyspark.sql import SparkSession
from shared.utils import read_schema


def _read_data(spark, config):
    schema_lst = config.get("schema")
    schema = read_schema(schema_lst)
    file_path = config.get('source_data_path')
    return spark.read.csv(file_path,
                          header=True,
                          schema=schema)


def run_job(spark, config):
    """ Runs Data Preparation job"""
    raw_df = _read_data(spark, config)
    df = Pipe([
        IF(IF.Predicate.has_column('DEFAULT'), then=[
            RemoveDuplicates(config['id_col'])
        ]),
        ConvertStrToDate(config['date_str_cols']),
        GetAge(config['age_cols']),
        ExtractTimePeriodMths(config['tenure_cols']),
        ReplaceStrRegex(config['str_replace_cols']),
        DropColumns(config['drop_cols']),
        SaveToParquet(config['processed_data_dir'] + '{}.csv'.format(phase.name)),
    ]).transform(raw_df)
    return df