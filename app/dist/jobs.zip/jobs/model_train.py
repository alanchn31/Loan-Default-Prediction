import json
from pyspark.sql import SparkSession
from shared.read_schema import read_schema


def _extract_data(spark, config):
    schema_lst = config.get("schema")
    schema = read_schema(schema_lst)
    file_path = f"{config.get('source_data_path')}/loan_default.csv"
    return spark.read.csv(file_path,
                          header=True,
                          schema=schema)

# labels = [
#     ('ID', typ.IntegerType()),
#     ('DISBURSED_VALUE', typ.IntegerType()),
#     ('ASSET_COST', typ.IntegerType()),
#     ('LOAN_TO_VALUE', typ.DoubleType()),
#     ('BRANCH_ID', typ.IntegerType()),
#     ('SUPPLIER_ID', typ.IntegerType()),
#     ('MANUFACTURER_ID', typ.IntegerType()),
#     ('PINCODE', typ.IntegerType()),
#     ('DOB', typ.StringType()),
#     ('EMP_TYPE', typ.StringType()),
#     ('DISBURSED_DATE', typ.StringType()),
#     ('REGION_ID', typ.IntegerType()),
#     ('EMPLOYEE_CODE_ID', typ.IntegerType()),
#     ('MOBILENO_AVL_FLAG', typ.IntegerType()),
#     ('ID1_FLAG', typ.IntegerType()),
#     ('ID2_FLAG', typ.IntegerType()),
#     ('ID3_FLAG', typ.IntegerType()),
#     ('ID4_FLAG', typ.IntegerType()),
#     ('ID5_FLAG', typ.IntegerType()),
#     ('BUREAU_SCORE', typ.IntegerType()),
#     ('SCORE_CATEGORY', typ.StringType()),
#     ('PRI_ACCS', typ.IntegerType()),
#     ('ACTIVE_ACCS', typ.IntegerType()),
#     ('OVERDUE_ACCS', typ.IntegerType()),
#     ('TOTAL_BALANCE_OUTSTANDING', typ.IntegerType()),
#     ('TOTAL_SANCTIONED_AMT', typ.IntegerType()),
#     ('TOTAL_DISBURSED_AMT', typ.IntegerType()),
#     ('SEC_ACCS', typ.IntegerType()),
#     ('SEC_ACTIVE_ACCS', typ.IntegerType()),
#     ('SEC_OVERDUE_ACCS', typ.IntegerType()),
#     ('SEC_TOTAL_BALANCE_OUTSTANDING', typ.IntegerType()),
#     ('SEC_TOTAL_SANCTIONED_AMT', typ.IntegerType()),
#     ('SEC_TOTAL_DISBURSED_AMT', typ.IntegerType()),
#     ('PRI_EMI', typ.IntegerType()),
#     ('SEC_EMI', typ.IntegerType()),
#     ('LOANS_6_MTHS', typ.IntegerType()),
#     ('LOANS_DEFAULT_6_MTHS', typ.IntegerType()),
#     ('AVG_LOAN_TENURE', typ.StringType()),
#     ('CREDIT_HIST_LEN', typ.StringType()),
#     ('INQUIRIES', typ.IntegerType()),
#     ('DEFAULT', typ.IntegerType())
# ]

# schema = typ.StructType([
#   typ.StructField(e[0], e[1], True)
#   for e in labels
# ])

def run_job(spark, config):
    """ Runs model training job"""
    raw_df = _extract_data(spark, config)
    print(raw_df.take(5))